document.addEventListener('DOMContentLoaded', function() {
    // Initialize sidebar toggle functionality
    initSidebar();
    
    // Initialize charts if Chart.js is loaded and we have the dashboard page
    if (typeof Chart !== 'undefined' && document.getElementById('profitChart')) {
        initCharts();
    }
    
    // Initialize datatables if present
    if (typeof $.fn.DataTable !== 'undefined') {
        initDataTables();
    }
    
    // Initialize form event listeners
    initFormListeners();
});

// Initialize sidebar toggle functionality
function initSidebar() {
    const hamburgerMenu = document.querySelector('.hamburger-menu');
    const sidebarClose = document.querySelector('.sidebar-close');
    const sidebar = document.querySelector('.admin-sidebar');
    
    if (hamburgerMenu && sidebar) {
        hamburgerMenu.addEventListener('click', function() {
            sidebar.classList.add('show');
        });
    }
    
    if (sidebarClose && sidebar) {
        sidebarClose.addEventListener('click', function() {
            sidebar.classList.remove('show');
        });
    }
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(event) {
        if (window.innerWidth < 992 && 
            sidebar && 
            sidebar.classList.contains('show') && 
            !sidebar.contains(event.target) && 
            !hamburgerMenu.contains(event.target)) {
            sidebar.classList.remove('show');
        }
    });
}

// Initialize charts for dashboard
function initCharts() {
    // Set Chart.js defaults for dark theme
    Chart.defaults.color = '#94a3b8';
    Chart.defaults.borderColor = 'rgba(255, 255, 255, 0.1)';
    
    // Get chart data from the page
    const chartData = JSON.parse(document.getElementById('chartData').getAttribute('data-chart'));
    
    // Profit Chart
    const profitChartCtx = document.getElementById('profitChart').getContext('2d');
    const profitChart = new Chart(profitChartCtx, {
        type: 'line',
        data: {
            labels: chartData.map(item => item.date),
            datasets: [{
                label: 'Daily Profit (₹)',
                data: chartData.map(item => item.profits),
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                borderWidth: 2,
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: '#1e293b',
                    titleColor: '#f8fafc',
                    bodyColor: '#f8fafc',
                    borderColor: '#334155',
                    borderWidth: 1,
                    padding: 12,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return '₹ ' + context.raw.toLocaleString('en-IN', {
                                maximumFractionDigits: 2,
                                minimumFractionDigits: 2
                            });
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)'
                    },
                    ticks: {
                        callback: function(value) {
                            return '₹ ' + value.toLocaleString('en-IN');
                        }
                    }
                }
            }
        }
    });
    
    // Users Chart
    const usersChartCtx = document.getElementById('usersChart').getContext('2d');
    const usersChart = new Chart(usersChartCtx, {
        type: 'line',
        data: {
            labels: chartData.map(item => item.date),
            datasets: [{
                label: 'Active Users',
                data: chartData.map(item => item.active_users),
                borderColor: '#4f46e5',
                backgroundColor: 'rgba(79, 70, 229, 0.1)',
                borderWidth: 2,
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: '#1e293b',
                    titleColor: '#f8fafc',
                    bodyColor: '#f8fafc',
                    borderColor: '#334155',
                    borderWidth: 1,
                    padding: 12,
                    displayColors: false
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)'
                    }
                }
            }
        }
    });
}

// Initialize DataTables
function initDataTables() {
    $('.admin-datatable').each(function() {
        $(this).DataTable({
            responsive: true,
            dom: 'frtip',
            pageLength: 10,
            language: {
                search: '',
                searchPlaceholder: 'Search...',
                paginate: {
                    previous: '<i class="fas fa-chevron-left"></i>',
                    next: '<i class="fas fa-chevron-right"></i>'
                }
            },
            initComplete: function() {
                // Style the search input
                $('.dataTables_filter input')
                    .addClass('form-control form-control-sm')
                    .css({
                        'width': '200px',
                        'display': 'inline-block'
                    });
                
                // Add a wrapper for search with icon
                $('.dataTables_filter').prepend('<i class="fas fa-search search-icon"></i>');
            }
        });
    });
}

// Initialize form event listeners
function initFormListeners() {
    // User search form
    const userSearchForm = document.getElementById('userSearchForm');
    if (userSearchForm) {
        userSearchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const searchTerm = document.getElementById('userSearchInput').value.trim();
            if (searchTerm.length < 2) return;
            
            // Show loading spinner
            const submitBtn = userSearchForm.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Searching...';
            submitBtn.disabled = true;
            
            // Submit the form
            this.submit();
        });
    }
    
    // Add funds form
    const addFundsForm = document.getElementById('addFundsForm');
    if (addFundsForm) {
        addFundsForm.addEventListener('submit', function(e) {
            const amountInput = document.getElementById('fundAmount');
            const amount = parseFloat(amountInput.value);
            
            if (isNaN(amount) || amount <= 0) {
                e.preventDefault();
                alert('Please enter a valid amount greater than 0');
                return;
            }
        });
    }
    
    // Toggle switches
    const toggleSwitches = document.querySelectorAll('.toggle-control input[type="checkbox"]');
    toggleSwitches.forEach(toggleSwitch => {
        toggleSwitch.addEventListener('change', function() {
            if (this.id === 'lossMode') {
                document.getElementById('toggleLossModeForm').submit();
            }
        });
    });
    
    // Game settings form
    const gameSettingsForm = document.getElementById('gameSettingsForm');
    if (gameSettingsForm) {
        const minBetInput = document.getElementById('minBet');
        const maxBetInput = document.getElementById('maxBet');
        
        gameSettingsForm.addEventListener('submit', function(e) {
            const minBet = parseFloat(minBetInput.value);
            const maxBet = parseFloat(maxBetInput.value);
            
            if (isNaN(minBet) || minBet <= 0) {
                e.preventDefault();
                alert('Minimum bet must be greater than 0');
                return;
            }
            
            if (isNaN(maxBet) || maxBet <= minBet) {
                e.preventDefault();
                alert('Maximum bet must be greater than minimum bet');
                return;
            }
        });
    }
}

// Function for generating random data (used for testing charts)
function generateRandomData(days) {
    const data = [];
    const today = new Date();
    
    for (let i = days - 1; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        
        data.push({
            date: date.toISOString().split('T')[0],
            profits: Math.round(Math.random() * 10000 + 5000),
            active_users: Math.round(Math.random() * 50 + 20)
        });
    }
    
    return data;
}

// Function to confirm actions
function confirmAction(message, formId) {
    if (confirm(message)) {
        document.getElementById(formId).submit();
    }
    return false;
}

// Function to format currency
function formatCurrency(amount) {
    return '₹ ' + amount.toLocaleString('en-IN', {
        maximumFractionDigits: 2,
        minimumFractionDigits: 2
    });
}
