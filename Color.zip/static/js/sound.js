// Sound effects for the application
let audioContext = null;
let gainNode = null;
let oscillator = null;

// Sound samples
const soundSamples = {
    button: {
        frequency: 800,
        type: 'triangle',
        duration: 0.1,
        gain: 0.2
    },
    select: {
        frequency: 600,
        type: 'sine',
        duration: 0.08,
        gain: 0.15
    },
    tick: {
        frequency: 400,
        type: 'sine',
        duration: 0.05,
        gain: 0.1
    },
    newRound: {
        frequency: 700,
        type: 'square',
        duration: 0.2,
        gain: 0.15
    },
    win: {
        notes: [
            { frequency: 523.25, duration: 0.1 }, // C
            { frequency: 659.25, duration: 0.1 }, // E
            { frequency: 783.99, duration: 0.2 }  // G
        ],
        gain: 0.3
    },
    loss: {
        notes: [
            { frequency: 392.00, duration: 0.1 }, // G
            { frequency: 349.23, duration: 0.2 }  // F
        ],
        gain: 0.2
    },
    welcome: {
        notes: [
            { frequency: 523.25, duration: 0.1 }, // C
            { frequency: 659.25, duration: 0.1 }, // E
            { frequency: 783.99, duration: 0.1 }, // G
            { frequency: 1046.50, duration: 0.2 } // C (higher octave)
        ],
        gain: 0.2
    },
    premium: {
        notes: [
            { frequency: 523.25, duration: 0.07 }, // C
            { frequency: 587.33, duration: 0.07 }, // D
            { frequency: 659.25, duration: 0.07 }, // E
            { frequency: 698.46, duration: 0.07 }, // F
            { frequency: 783.99, duration: 0.07 }, // G
            { frequency: 880.00, duration: 0.07 }, // A
            { frequency: 987.77, duration: 0.07 }, // B
            { frequency: 1046.50, duration: 0.2 }  // C (higher octave)
        ],
        gain: 0.3
    }
};

// Ensure audio context is created
function ensureAudioContext() {
    if (!audioContext && window.AudioContext) {
        audioContext = new window.AudioContext();
        // Create a master gain node
        gainNode = audioContext.createGain();
        gainNode.gain.value = 0.5; // Master volume at 50%
        gainNode.connect(audioContext.destination);
    }
    return audioContext !== null;
}

// Play a simple UI sound
function playUISound(soundType) {
    if (!ensureAudioContext() || !soundSamples[soundType]) return;
    
    // Resume audio context if it's suspended (browser policy)
    if (audioContext.state === 'suspended') {
        audioContext.resume();
    }
    
    const sound = soundSamples[soundType];
    
    // Create oscillator
    const osc = audioContext.createOscillator();
    osc.type = sound.type;
    osc.frequency.value = sound.frequency;
    
    // Create gain node for this sound
    const soundGain = audioContext.createGain();
    soundGain.gain.value = sound.gain;
    
    // Connect nodes
    osc.connect(soundGain);
    soundGain.connect(gainNode);
    
    // Start and stop the oscillator
    osc.start();
    
    // Fade out to avoid clicks
    soundGain.gain.exponentialRampToValueAtTime(
        0.001, audioContext.currentTime + sound.duration
    );
    
    osc.stop(audioContext.currentTime + sound.duration);
}

// Play a melody of notes
function playMelody(notes, gain = 0.3) {
    if (!ensureAudioContext()) return;
    
    // Resume audio context if it's suspended (browser policy)
    if (audioContext.state === 'suspended') {
        audioContext.resume();
    }
    
    // Create gain node for this melody
    const melodyGain = audioContext.createGain();
    melodyGain.gain.value = gain;
    melodyGain.connect(gainNode);
    
    let timeOffset = 0;
    
    notes.forEach(note => {
        // Create oscillator for each note
        const osc = audioContext.createOscillator();
        osc.type = note.type || 'sine';
        osc.frequency.value = note.frequency;
        
        // Connect to the melody gain node
        osc.connect(melodyGain);
        
        // Schedule start and stop times
        osc.start(audioContext.currentTime + timeOffset);
        osc.stop(audioContext.currentTime + timeOffset + note.duration);
        
        // Update time offset for next note
        timeOffset += note.duration;
    });
}

// Play welcome sound
function playWelcomeSound() {
    if (!ensureAudioContext() || !soundSamples.welcome) return;
    playMelody(soundSamples.welcome.notes, soundSamples.welcome.gain);
}

// Play premium subscription sound
function playPremiumSound() {
    if (!ensureAudioContext() || !soundSamples.premium) return;
    playMelody(soundSamples.premium.notes, soundSamples.premium.gain);
}

// Play tab change sound
function playTabSound() {
    playUISound('select');
}

// Play game result sound
function playGameSound(type, resultColor) {
    if (!ensureAudioContext()) return;
    
    // Resume audio context if it's suspended (browser policy)
    if (audioContext.state === 'suspended') {
        audioContext.resume();
    }
    
    if (type === 'result') {
        // Different sounds based on color
        let frequency, oscillatorType;
        
        switch (resultColor) {
            case 'red':
                frequency = 330;
                oscillatorType = 'sawtooth';
                break;
            case 'green':
                frequency = 440;
                oscillatorType = 'sine';
                break;
            case 'violet':
                frequency = 550;
                oscillatorType = 'triangle';
                break;
            default:
                frequency = 440;
                oscillatorType = 'sine';
        }
        
        // Create oscillator
        const osc = audioContext.createOscillator();
        osc.type = oscillatorType;
        osc.frequency.value = frequency;
        
        // Create gain node for this sound
        const soundGain = audioContext.createGain();
        soundGain.gain.value = 0.3;
        
        // Connect nodes
        osc.connect(soundGain);
        soundGain.connect(gainNode);
        
        // Start and stop the oscillator
        osc.start();
        
        // Frequency slide for more interesting sound
        osc.frequency.exponentialRampToValueAtTime(
            frequency * 1.5, audioContext.currentTime + 0.1
        );
        osc.frequency.exponentialRampToValueAtTime(
            frequency, audioContext.currentTime + 0.3
        );
        
        // Fade out to avoid clicks
        soundGain.gain.exponentialRampToValueAtTime(
            0.001, audioContext.currentTime + 0.5
        );
        
        osc.stop(audioContext.currentTime + 0.5);
    } else if (type === 'win') {
        playMelody(soundSamples.win.notes, soundSamples.win.gain);
    } else if (type === 'loss') {
        playMelody(soundSamples.loss.notes, soundSamples.loss.gain);
    }
}

// Set master volume
function setMasterVolume(volume) {
    if (!ensureAudioContext()) return;
    gainNode.gain.value = Math.max(0, Math.min(1, volume));
}

// Mute/unmute all sounds
function toggleMute(mute) {
    if (!ensureAudioContext()) return;
    gainNode.gain.value = mute ? 0 : 0.5;
}
