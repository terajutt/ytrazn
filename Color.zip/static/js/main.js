document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Floating Currency Background Effect
    createFloatingBackground();
    
    // Initialize the audio context
    initAudioContext();
});

// Create floating currency symbols in the background
function createFloatingBackground() {
    // This function is already managed by the CSS with the animated-icons div
    // The effect is created using the animated-icons class and its CSS animations
}

// For handling the audio context initialization
function initAudioContext() {
    // Initialize the audio context when user interacts with the page
    document.addEventListener('click', function initAudio() {
        // Check if we already have initialized audio
        if (window.audioInitialized) return;
        
        // Create a dummy AudioContext to initialize audio system
        // This will be used by the sound.js file
        window.AudioContext = window.AudioContext || window.webkitAudioContext;
        window.audioContext = new AudioContext();
        window.audioInitialized = true;
        
        // Remove the listener after initialization
        document.removeEventListener('click', initAudio);
        
        console.log('Audio context initialized');
    }, { once: true });
}

// Function to handle form submissions with a loading indicator
function submitFormWithLoading(formId, loadingText = 'Processing...') {
    const form = document.getElementById(formId);
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        const submitBtn = form.querySelector('button[type="submit"]');
        if (!submitBtn) return;
        
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> ${loadingText}`;
        
        // Allow the form to continue submitting
    });
}

// Function to toggle password visibility
function togglePasswordVisibility(inputId, toggleBtnId) {
    const passwordInput = document.getElementById(inputId);
    const toggleBtn = document.getElementById(toggleBtnId);
    
    if (!passwordInput || !toggleBtn) return;
    
    toggleBtn.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        
        // Toggle icon
        if (type === 'text') {
            toggleBtn.innerHTML = '<i class="fas fa-eye-slash"></i>';
        } else {
            toggleBtn.innerHTML = '<i class="fas fa-eye"></i>';
        }
    });
}

// Format currency numbers
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 2
    }).format(amount);
}

// Copy text to clipboard
function copyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed'; // Avoid scrolling to bottom
    document.body.appendChild(textarea);
    textarea.select();
    
    try {
        document.execCommand('copy');
        return true;
    } catch (err) {
        console.error('Failed to copy: ', err);
        return false;
    } finally {
        document.body.removeChild(textarea);
    }
}

// Show a toast notification
function showToast(message, type = 'info', duration = 3000) {
    // Check if toast container exists, if not create it
    let toastContainer = document.querySelector('.toast-container');
    
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastEl = document.createElement('div');
    toastEl.className = `toast align-items-center text-white bg-${type} border-0`;
    toastEl.setAttribute('role', 'alert');
    toastEl.setAttribute('aria-live', 'assertive');
    toastEl.setAttribute('aria-atomic', 'true');
    
    // Set toast content
    toastEl.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    // Add toast to container
    toastContainer.appendChild(toastEl);
    
    // Initialize Bootstrap toast
    const toast = new bootstrap.Toast(toastEl, {
        autohide: true,
        delay: duration
    });
    
    // Show toast
    toast.show();
    
    // After the toast is hidden, remove it from DOM
    toastEl.addEventListener('hidden.bs.toast', function() {
        toastContainer.removeChild(toastEl);
    });
}

// Function to create animated text
function createAnimatedText(elementId, text, delay = 50) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    element.textContent = '';
    
    // Add each character with a delay
    let index = 0;
    const interval = setInterval(() => {
        element.textContent += text[index];
        index++;
        
        if (index >= text.length) {
            clearInterval(interval);
        }
    }, delay);
}
