// Global variables
let gameState = null;
let gameTimer = null;
let currentRound = null;
let selectedColor = null;
let gameUpdater = null;
let lastProcessedRound = null; // Track the last round we processed a result for

// Initialize the game
function initGame(initialState) {
    gameState = initialState;
    currentRound = gameState.round_id;

    // Update the UI with initial state
    updateGameInterface(gameState);

    // Start timer
    startTimer(gameState.time_remaining);

    // Setup color selection
    setupColorSelection();

    // Start game state updater
    startGameUpdater();

    // Setup quick amount buttons
    setupQuickAmountButtons();
}

// Setup event listeners for color selection
function setupColorSelection() {
    const colorOptions = document.querySelectorAll('.color-option');

    colorOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove selected class from all options
            colorOptions.forEach(opt => opt.classList.remove('selected'));

            // Add selected class to clicked option
            this.classList.add('selected');

            // Update hidden input field with selected color
            selectedColor = this.dataset.color;
            document.getElementById('selectedColor').value = selectedColor;

            // Enable the bet button if an amount is entered
            checkBetFormValidity();

            // Play selection sound
            playColorSelectSound(selectedColor);
        });
    });

    // Monitor bet amount field
    const betAmount = document.getElementById('betAmount');
    betAmount.addEventListener('input', checkBetFormValidity);

    // Setup bet form submission with AJAX
    const betForm = document.getElementById('betForm');
    betForm.addEventListener('submit', function(e) {
        e.preventDefault();

        // Play button sound
        playButtonSound();

        // Show loading state on button
        const submitBtn = document.getElementById('placeBetBtn');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = 'Placing Bet...';

        // Create FormData object
        const formData = new FormData(betForm);

        // Send AJAX request
        fetch('/place_bet', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Reset button state
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;

            // Handle response
            if (data.success) {
                // Show success message
                if (typeof showToast === 'function') {
                    showToast(data.message, 'success');
                } else {
                    alert(data.message);
                }

                // Update user balance if provided
                if (data.user_balance_formatted) {
                    const balanceElements = document.querySelectorAll('.user-balance');
                    balanceElements.forEach(element => {
                        element.textContent = data.user_balance_formatted;
                    });
                }

                // Add the bet to recent bets list
                addBetToUserList(formData.get('color'), formData.get('amount'));

                // Reset the form
                betForm.reset();
                colorOptions.forEach(opt => opt.classList.remove('selected'));
                selectedColor = null;
                checkBetFormValidity();
            } else {
                // Show error message
                if (typeof showToast === 'function') {
                    showToast(data.message, 'danger');
                } else {
                    alert(data.message);
                }
            }
        })
        .catch(error => {
            console.error('Error placing bet:', error);

            // Reset button state
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;

            // Show error message
            if (typeof showToast === 'function') {
                showToast('An error occurred while placing your bet.', 'danger');
            } else {
                alert('An error occurred while placing your bet.');
            }
        });
    });
}

// Setup quick amount buttons
function setupQuickAmountButtons() {
    const quickAmountButtons = document.querySelectorAll('.quick-amount');
    const betAmountInput = document.getElementById('betAmount');

    quickAmountButtons.forEach(button => {
        button.addEventListener('click', function() {
            betAmountInput.value = this.dataset.amount;
            checkBetFormValidity();
            playButtonSound();
        });
    });
}

// Check if bet form is valid and enable/disable button
function checkBetFormValidity() {
    const betAmount = document.getElementById('betAmount').value;
    const betButton = document.getElementById('placeBetBtn');

    // Enable button only if both amount and color are selected
    if (betAmount > 0 && selectedColor) {
        betButton.disabled = false;
    } else {
        betButton.disabled = true;
    }
}

// Start the game timer
function startTimer(timeRemaining) {
    if (gameTimer) {
        clearInterval(gameTimer);
        gameTimer = null;
    }

    const timerElement = document.getElementById('timer');
    const timerBar = document.getElementById('timerBar');

    if (!timerElement || !timerBar) return;

    let timeLeft = Math.max(0, Math.floor(timeRemaining));
    if (timeLeft <= 0) {
        updateTimerDisplay(0);
        timerBar.style.width = '0%';
        lockBettingForm();
        return;
    }

    const totalTime = timeLeft;
    const startTime = Date.now();

    function tick() {
        const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
        timeLeft = Math.max(0, totalTime - elapsedSeconds);
        
        const percentage = (timeLeft / totalTime) * 100;
        updateTimerDisplay(timeLeft);
        timerBar.style.width = `${percentage}%`;

        if (timeLeft <= 5 && timeLeft > 0) {
            playTickSound();
        }

        if (timeLeft <= 0) {
            clearInterval(gameTimer);
            gameTimer = null;
            updateTimerDisplay(0);
            timerBar.style.width = '0%';
            lockBettingForm();
        }
    }

    tick();
    gameTimer = setInterval(tick, 100);
}

// Update timer display
function updateTimerDisplay(timeInSeconds) {
    const timerElement = document.getElementById('timer');
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60); // Make sure seconds is an integer

    timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

    // Change color when time is running low
    if (timeInSeconds <= 10) {
        timerElement.style.color = '#ef4444';
    } else {
        timerElement.style.color = '';
    }
}

// Lock the betting form (can't place bets when timer reaches zero)
function lockBettingForm() {
    const betForm = document.getElementById('betForm');
    const betButton = document.getElementById('placeBetBtn');
    const betAmount = document.getElementById('betAmount');
    const colorOptions = document.querySelectorAll('.color-option');

    // Disable all form elements
    betButton.disabled = true;
    betAmount.disabled = true;
    colorOptions.forEach(option => {
        option.style.opacity = '0.5';
        option.style.pointerEvents = 'none';
    });
}

// Unlock the betting form (for new round)
function unlockBettingForm() {
    const betForm = document.getElementById('betForm');
    const betButton = document.getElementById('placeBetBtn');
    const betAmount = document.getElementById('betAmount');
    const colorOptions = document.querySelectorAll('.color-option');

    // Enable form elements
    betAmount.disabled = false;
    colorOptions.forEach(option => {
        option.style.opacity = '1';
        option.style.pointerEvents = 'auto';
    });

    // Reset color selection
    colorOptions.forEach(opt => opt.classList.remove('selected'));
    selectedColor = null;
    document.getElementById('selectedColor').value = '';

    // Check validity to determine if button should be enabled
    checkBetFormValidity();
}

// Start game updater to fetch latest game state
function startGameUpdater() {
    // Clear existing updater if any
    if (gameUpdater) {
        clearInterval(gameUpdater);
    }

    const updateGameState = () => {
        if (typeof EventSource !== "undefined") {
            const source = new EventSource('/game_state_stream');

            source.onmessage = function(event) {
                const data = JSON.parse(event.data);
                if (data.error) {
                    console.error('Server error:', data.error);
                    source.close();
                    return;
                }
                updateGameInterface(data);

                // Always update user balance when received
                if (data.user_balance_formatted) {
                    const balanceElements = document.querySelectorAll('.user-balance');
                    balanceElements.forEach(element => {
                        element.innerText = data.user_balance_formatted;
                    });
                }

                // Update recent bets if available
                if (data.recent_bets) {
                    const betsList = document.querySelector('.bets-list');
                    if (betsList) {
                        betsList.innerHTML = data.recent_bets.map(bet => `
                            <div class="bet-item">
                                <div class="bet-game">Game #${bet.game_round_id}</div>
                                <div class="bet-color-badge" style="background-color: ${bet.color}">
                                    ${bet.color.toUpperCase()}
                                </div>
                                <div class="bet-amount">₹${bet.amount}</div>
                                <div class="bet-result ${bet.is_win ? 'win' : 'loss'}">
                                    ${bet.is_win ? 
                                        `<i class="fas fa-check-circle"></i> +₹${bet.payout.toFixed(2)}` :
                                        `<i class="fas fa-times-circle"></i> Loss`}
                                </div>
                            </div>
                        `).join('');
                    }
                }
            };

            source.onerror = function(error) {
                console.error('EventSource error:', error);
                source.close();
                // Retry connection after 5 seconds
                setTimeout(() => updateGameState(), 5000);
            };
        } else {
            // Fallback for browsers that don't support SSE
            setInterval(() => {
                fetch('/game_state')
                    .then(response => response.json())
                    .then(data => updateGameInterface(data))
                    .catch(error => console.error('Error:', error));
            }, 1000);
        }
    };

    updateGameState();
}


// Fetch the current game state
function fetchGameState() {
    fetch('/game_state')
        .then(response => response.json())
        .then(data => {
            // Check if it's a new round
            if (data.round_id !== currentRound) {
                handleNewRound(data);
            }

            // Check if result has been announced
            if (data.status === 'ended' && data.result !== null && 
                data.round_id !== lastProcessedRound && 
                (gameState.result === null || gameState.round_id !== data.round_id)) {
                handleResultAnnouncement(data);
            }

            // Update game state
            gameState = data;

            // Update the round number display
            document.getElementById('roundNumber').textContent = data.round_id;

            // Update user balance if available (real-time balance updates)
            if (data.user_balance !== undefined) {
                // Find all elements with class 'user-balance' and update them
                const balanceElements = document.querySelectorAll('.user-balance');
                balanceElements.forEach(element => {
                    element.textContent = data.user_balance_formatted;
                });
            }
        })
        .catch(error => console.error('Error fetching game state:', error));
}

// Handle new round
function handleNewRound(data) {
    console.log('New round started:', data.round_id);
    currentRound = data.round_id;

    // Update round number
    document.getElementById('roundNumber').textContent = data.round_id;

    // Reset and start timer
    startTimer(data.time_remaining);

    // Unlock betting form
    unlockBettingForm();

    // Play new round sound
    playNewRoundSound();
}

// Handle result announcement
function handleResultAnnouncement(data) {
    console.log('Result announced:', data.result_color, data.result);

    // Update the result display
    updateResultDisplay(data.result_color, data.result);

    // Play result sound
    playResultSound(data.result_color);

    // Add result to history
    addResultToHistory(data.round_id, data.result_color, data.result);

    // Update pending bets status
    updatePendingBets(data.round_id, data.result_color, data.result);

    // Store the last result round number to avoid duplicate displays
    lastProcessedRound = data.round_id;
}

// Add a result to the history
function addResultToHistory(roundId, color, number) {
    // Find the results history list
    const resultsContainer = document.querySelector('.recent-results');
    if (!resultsContainer) return;

    // Format time
    const now = new Date();
    const timeString = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;

    // Create result item
    const resultItem = document.createElement('div');
    resultItem.className = 'result-item';

    // Format the result
    resultItem.innerHTML = `
        <div class="result-round">#${roundId}</div>
        <div class="result-value">
            <span class="result-color-box" style="background-color: ${color};"></span>
            <span class="result-number">${number}</span>
        </div>
        <div class="result-time">${timeString}</div>
    `;

    // Add to container at the beginning
    if (resultsContainer.firstChild) {
        resultsContainer.insertBefore(resultItem, resultsContainer.firstChild);
    } else {
        resultsContainer.appendChild(resultItem);
    }

    // Limit the number of results shown (keep last 10)
    const allResults = resultsContainer.querySelectorAll('.result-item');
    if (allResults.length > 10) {
        // Convert NodeList to Array for safe manipulation
        const resultsArray = Array.from(allResults);
        // Remove excess elements (after the first 10)
        resultsArray.slice(10).forEach(item => {
            if (item.parentNode === resultsContainer) {
                resultsContainer.removeChild(item);
            }
        });
    }
}

// Update pending bets after result is announced
function updatePendingBets(roundId, resultColor, resultNumber) {
    // Find all pending bets for this round
    const pendingBets = document.querySelectorAll('.bet-item .bet-round');

    pendingBets.forEach(betRoundElement => {
        // Extract round number from the text "#123"
        const betRoundText = betRoundElement.textContent.trim();
        const betRoundNumber = parseInt(betRoundText.replace(/[^0-9]/g, ''));

        if (betRoundNumber === roundId) {
            const betItem = betRoundElement.closest('.bet-item');
            const statusElement = betItem.querySelector('.bet-status');
            const betColorElement = betItem.querySelector('.bet-color');

            if (statusElement && betColorElement) {
                const betColor = betColorElement.textContent.trim().toLowerCase();

                // Determine if bet won based on color
                const isWinner = 
                    (betColor === resultColor) || 
                    (betColor === 'violet' && (resultNumber === 0 || resultNumber % 5 === 0));

                // Update status element
                statusElement.classList.remove('pending');
                if (isWinner) {
                    statusElement.classList.add('win');
                    statusElement.textContent = 'WIN';
                } else {
                    statusElement.classList.add('loss');
                    statusElement.textContent = 'LOSS';
                }
            }
        }
    });
}

// Update the game interface with current state
function updateGameInterface(state) {
    // Update round number
    document.getElementById('roundNumber').textContent = state.round_id;

    // Update timer
    updateTimerDisplay(state.time_remaining);

    // If in ended state with a result, show it
    if (state.status === 'ended' && state.result !== null) {
        updateResultDisplay(state.result_color, state.result);
    }

    // If in active state, enable betting form, otherwise lock it
    if (state.status === 'active') {
        unlockBettingForm();
    } else {
        lockBettingForm();
    }
}

// Update the result display
function updateResultDisplay(color, number) {
    const resultDisplay = document.getElementById('resultDisplay');

    resultDisplay.innerHTML = `
        <div class="result-color result-reveal" style="background-color: ${color}">
            ${color.toUpperCase()}
        </div>
        <div class="result-number result-reveal">${number}</div>
    `;
}

// Play a sound when selecting a color
function playColorSelectSound(color) {
    if (typeof playUISound === 'function') {
        playUISound('select');
    }
}

// Play a sound when clicking a button
function playButtonSound() {
    if (typeof playUISound === 'function') {
        playUISound('button');
    }
}

// Play a sound for the timer tick (last 5 seconds)
function playTickSound() {
    if (typeof playUISound === 'function') {
        playUISound('tick');
    }
}

// Play a sound when a new round starts
function playNewRoundSound() {
    if (typeof playUISound === 'function') {
        playUISound('newRound');
    }
}

// Play a sound when result is announced
function playResultSound(color) {
    if (typeof playGameSound === 'function') {
        playGameSound('result', color);
    }
}

// Add a bet to the user's recent bets list
function addBetToUserList(color, amount) {
    // Find the user bets list
    const betsList = document.querySelector('.user-bets');
    if (!betsList) return;

    // Create a new bet item
    const betItem = document.createElement('div');
    betItem.className = 'bet-item';

    // Format bet info
    betItem.innerHTML = `
        <div class="bet-round">Round #${currentRound}</div>
        <div class="bet-details">
            <span class="bet-amount">₹${parseFloat(amount).toFixed(2)}</span>
            <span class="bet-color" style="background-color: ${color};">${color.toUpperCase()}</span>
            <span class="bet-status pending">Pending</span>
        </div>
    `;

    // Add to list at the beginning
    if (betsList.firstChild) {
        betsList.insertBefore(betItem, betsList.firstChild);
    } else {
        betsList.appendChild(betItem);
    }
}

function updateRecentBets(bets) {
    const betsList = document.querySelector('.user-bets');
    if (!betsList) return;
    betsList.innerHTML = ''; // Clear existing bets

    bets.forEach(bet => {
        const betItem = document.createElement('div');
        betItem.className = 'bet-item';
        betItem.innerHTML = `
            <div class="bet-round">Round #${bet.game_round_id}</div>
            <div class="bet-details">
                <span class="bet-amount">₹${parseFloat(bet.amount).toFixed(2)}</span>
                <span class="bet-color" style="background-color: ${bet.color};">${bet.color.toUpperCase()}</span>
                <span class="bet-status ${bet.is_win ? 'win' : 'loss'}">${bet.is_win ? 'WIN' : 'LOSS'}</span>
                <span class="bet-payout">${bet.payout ? '₹' + parseFloat(bet.payout).toFixed(2) : ''}</span>
            </div>
        `;
        betsList.appendChild(betItem);
    });

}